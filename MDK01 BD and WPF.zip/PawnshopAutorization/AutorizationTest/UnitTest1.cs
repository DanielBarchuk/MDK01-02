﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using PawnshopAutorization;

namespace AutorizationTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AutorizationTestMethod1()
        {
            //вводим данные одного из сотрудников
            string login = "sotrudnik";
            string password = "sotrudnik";

            bool result = MainWindow.Autorization(login, password);


            Assert.AreEqual(result, true); //ожидаем успешной авторизации и успешного выполнения теста
        }
    }
}
