﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PawnshopAutorization
{
    internal class DB
    {
        public static PawnshopEntities conObj;

        public static PawnshopEntities getcontext()
        {
            if (conObj == null) conObj = new PawnshopEntities();
            return conObj;
        }
    }
}
