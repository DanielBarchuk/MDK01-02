﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PawnshopAutorization
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_autorization_Click(object sender, RoutedEventArgs e)
        {
            if (Autorization(txt_password.Password, txt_Login.Text))
            {
                MessageBox.Show("Авторизация успешна");
            }
        }


        private void btn_cancel_Click(object sender, RoutedEventArgs e)
        {
            txt_Login.Text = "";
            txt_password.Password = "";
        }

       public static bool Autorization(string login, string password)
        {
          
                try
                {

                    var users = DB.getcontext().Employee.ToList();

                    var user = users.FirstOrDefault(u =>
                    u.Login == login
                    &&
                    u.Password == password);

                    if (user != null)
                    {
                        return true;                      
                    }

                    else
                    {

                    MessageBox.Show("Авторизация не успешна");
                    return false;                      
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    Console.ReadKey();
                }
            return false;
        }

        private void txt_Login_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
